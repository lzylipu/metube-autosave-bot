class MeTubeException(Exception):
    def __init__(self, message: str):
        super().__init__(f"MeTube: {message}")
